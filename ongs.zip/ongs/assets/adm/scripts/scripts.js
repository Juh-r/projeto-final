const myH2 = document.createElement("h2");
myH2.innerHTML = "Aplicação do(s) Administradores do Sistema";

document.querySelector("h1").insertAdjacentElement("afterend",myH2);