const myH2 = document.createElement("h2");
myH2.innerHTML = "Aplicação do Usuário";

document.querySelector("h1").insertAdjacentElement("afterend",myH2);