# Pasta 01-bd
> Pasta para armazenar scripts relativos ao banco de dados, como criação ou dumps das informações. 