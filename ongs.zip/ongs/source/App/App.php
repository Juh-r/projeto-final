<?php

namespace Source\App;

use League\Plates\Engine;
use Source\Models\Category;
use Source\Models\User;
use Source\Models\Ong;

class App
{
    private $view;

    public function __construct()
    {
        if(empty($_SESSION["user"]) || empty($_COOKIE["user"])){
            header("Location:http://www.localhost/ongs/login");
        }
        setcookie("user","Logado",time()+60*60,"/");
        $this->view = new Engine(CONF_VIEW_APP,'php');
    }

    /*private $view;
    private $categories;
    private $ongs;

    public function __construct()
    {
        $categories = new Category();
        $this->categories = $categories->selectAll();
        $ongs = new Ong();
        $this->ongs = $ongs->selectAll();
        $this->view = new Engine(CONF_VIEW_APP,'php');
        //$this->view = new Engine(__DIR__ . "/../../themes/app",'php');
    }*/

    public function home () : void 
    {
        echo $this->view->render("home");

    }

    public function list () : void
    {
        require __DIR__ . "/../../themes/app/list.php";
    }

    public function createPDF () : void
    {
        require __DIR__ . "/../../themes/app/create-pdf.php";
    }



    public function logout()
    {
        session_destroy();
        setcookie("user","",time()-3600,"/");
        header("Location:http://www.localhost/ongs/login");
    }

    public function profile()
    {
        // buscar as informações do usuário da SESSION.
        // $user = $_SESSION["user"];
        // buscar as informações do usuário no BD
        $user = new User($_SESSION["user"]["id"]);
        $user->findById();

        //var_dump($user);

        echo $this->view->render("profile",[
            "user" => $user
        ]);
    }


    public function profileUpdate(array $data) : void
    {
        if(!empty($data)){

            if(in_array("",$data)){
                $userJson = [
                    "message" => "Informe todos os campos!",
                    "type" => "alert-danger"
                ];
                echo json_encode($userJson);
                return;
            }

            if(!empty($_FILES['photo']['tmp_name'])) {
                $upload = uploadImage($_FILES['photo']);
                unlink($_SESSION["user"]["photo"]);
            } else {
                // se não houve alteração da imagem, manda a imagem que está na sessão
                $upload = $_SESSION["user"]["photo"];
            }


            $user = new User(
                $_SESSION["user"]["id"],
                $data["name"],
                $data["email"],
                null ,
                null,
                $upload
            );
            $user->update();
            $userJson = [
                "message" => $user->getMessage(),
                "type" => "alert-success",
                "name" => $user->getName(),
                "email" => $user->getEmail(),
                "photo" => url($user->getPhoto())
            ];
            echo json_encode($userJson);
        }
    }
    

    /**
     * @return void
     */
   /* public function createOng(?array $data) : void
    {
        if(!empty($data)){

            if(in_array("", $data)){
                $json = [
                  "massage" => "Informe o nome de sua ong para registra-la no sistema",
                  "type" => "warning"
                ];
                echo json_encode($json);
                return;

            }

            $ong = new Ong(
                NULL,
                $data["title"],
                $data["abstract"],
                $data["localization"],
                NULL
            );

            if(!$ong->insert()){
                $json = [
                    "message" => $ong->getMessage(),
                    "type" => "error"
                ];
                echo json_encode($json);
                return;
            } else {
                $json = [
                    "title" => $data["title"],
                    "abstract" => $data["abstract"],
                    "message" => $ong->getMessage(),
                    "type" => "success"
                ];
                echo json_encode($json);
                return;
            }
            return;

        }
        echo $this->view->render("new-ong",[
            "categories" => $this->categories,
            "ongs" => $this->ongs,
            "eventName" => CONF_SITE_NAME
        ]);
    }*/



    public function ongRegister(array $data) : void
    {
        if(!empty($data)){
            $data = filter_var_array($data,FILTER_SANITIZE_FULL_SPECIAL_CHARS);
            $json = [
                "message" => "",
                "type" => "",
                "titulo" => $data["title"],
                "abstract" => $data["abstract"],
                "localization" => $data["localization"]
            ];

            $ong = new Ong(
                null,
                $data["title"],
                $data["abstract"],
                $data["text"],
                $data["localization"]
            );

            $ong->insert();

            echo json_encode($json);
            return;
        }

        $catagory = new Category();
        $categories = $catagory->selectAll();
        //var_dump($categories);
        echo $this->view->render("ong-register",[
            "categories" => $categories
        ]);
    }

}


  /*  public function error(array $data) : void
    {
      echo "<h1>Erro {$data["errcode"]}</h1>";
     include __DIR__ . "/../../themes/web/404.php";
        echo $this->view->render("404", [
            "title" => "Erro {$data["errcode"]} | " . CONF_SITE_NAME,
            "error" => $data["errcode"]
        ]);
    }
}*/