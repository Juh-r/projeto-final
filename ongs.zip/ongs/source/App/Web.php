<?php

namespace Source\App;

use League\Plates\Engine;
use Source\Models\User;
use Source\Models\Faq;
use Source\Models\Ong;
use Source\Models\Category;

class Web
{
    private $view;
    private $categories;

    public function __construct()
    {
        $categories = new Category();
        $this->categories = $categories->selectAll();
        $ongs = new Ong();
        $this->ongs = $ongs->selectAll();
        $this->view = new Engine(CONF_VIEW_WEB,'php');
        //$this->view = new Engine(__DIR__ . "/../../themes/web",'php');
    }

    public function home() : void
    {
         //require __DIR__ . "/../../themes/web/home.php";

        $user = new User(20);
        $user->findById();

        echo $this->view->render("home",[
            "categories" => $this->categories
        ]);
    }

    public function about() : void
    {
        echo $this->view->render("about",
            [
                "categories" => $this->categories
            ]); // Engine
    }

    public function login(?array $data) : void
    {
        if(!empty($data)){

            if(in_array("",$data)){
                $json = [
                    "message" => "Informe e-mail e senha para entrar!",
                    "type" => "warning"
                ];
                echo json_encode($json);
                return;
            }

            if(!is_email($data["email"])){
                $json = [
                    "message" => "Por favor, informe um e-mail válido!",
                    "type" => "warning"
                ];
                echo json_encode($json);
                return;
            }

            $user = new User();

            if(!$user->validate($data["email"],$data["password"])){
                $json = [
                    "message" => $user->getMessage(),
                    "type" => "error"
                ];
                echo json_encode($json);
                return;
            }

            $json = [
                "name" => $user->getName(),
                "email" => $user->getEmail(),
                "message" => $user->getMessage(),
                "type" => "success"
            ];
            echo json_encode($json);
            return;

        }

        echo $this->view->render("login",[
            "categories" => $this->categories,
            "eventName" => CONF_SITE_NAME
        ]);

    }

    public function register(?array $data) : void
    {
        if(!empty($data)){

            if(in_array("",$data)){
                $json = [
                    "message" => "Informe nome, e-mail e senha para cadastrar!",
                    "type" => "warning"
                ];
                echo json_encode($json);
                return;
            }

            if(!is_email($data["email"])){
                $json = [
                    "message" => "Informe um e-mail válido!",
                    "type" => "warning"
                ];
                echo json_encode($json);
                return;
            }

            $user = new User(
                NULL,
                $data["name"],
                $data["email"],
                $data["password"]
            );

            if($user->findByEmail($data["email"])){
                $json = [
                    "message" => "Email já cadastrado!",
                    "type" => "error"
                ];
                echo json_encode($json);
                return;
            }

            if(!$user->insert()){
                $json = [
                    "message" => $user->getMessage(),
                    "type" => "error"
                ];
                echo json_encode($json);
                return;
            } else {
                $json = [
                    "name" => $data["name"],
                    "email" => $data["email"],
                    "message" => $user->getMessage(),
                    "type" => "success"
                ];
                echo json_encode($json);
                return;
            }
            return;
        }

        echo $this->view->render("register",[
            "categories" => $this->categories,
            "eventName" => CONF_SITE_NAME
        ]);
    }

    //public function faq()
    //{
      //  $faq = new Faq();
      //  $faqs = $faq->selectAll();
        //var_dump($faqs);

      //  echo $this->view->render("faq",[
        //    "categories" => $this->categories,
         //   "faqs" => $faqs
       // ]);
   // }

    public function ongs(?array $data) : void
    {
        if(!empty($data)){
            $ong = new Ong();
            $ongs = $ong->findByCategory($data["idCategory"]);
        } else {
            $ong = new Ong();
            $ongs = $ong->selectAll();
        }
        echo $this->view->render(
            "ongs",[
                "categories" => $this->categories,
                "ongs" => $ongs
            ]
        );
    }


    public function localization()
    {
        //echo "Localização";
        echo $this->view->render("localization", [
            "categories" => $this->categories
        ]); // Engine
    }

    public function contact(array $data) : void
    {
        var_dump($data);
        echo $this->view->render("contact", [
          "categories" => $this->categories
        ]);
    }

    public function error(array $data) : void
    {
//      echo "<h1>Erro {$data["errcode"]}</h1>";
//      include __DIR__ . "/../../themes/web/404.php";
        echo $this->view->render("404", [
            "title" => "Erro {$data["errcode"]} | " . CONF_SITE_NAME,
            "error" => $data["errcode"]
        ]);
    }

}