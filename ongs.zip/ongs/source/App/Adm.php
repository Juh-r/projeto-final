<?php

namespace Source\App;

class Adm
{
    public function home () : void
    {
        require __DIR__ . "/../../themes/adm/home.php";
    }
}