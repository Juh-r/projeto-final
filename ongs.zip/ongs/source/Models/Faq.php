<?php

namespace Source\Models;

class Faq
{

}