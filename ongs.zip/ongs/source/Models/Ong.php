<?php

namespace Source\Models;

use Source\Core\Connect;

class Ong
{ 
    private $id;
    private $title;
    private $abstract;
    private $localization;
    private $idCategory;


    public function __construct(
        int $id = NULL,
        string $title = NULL,
        string $abstract = NULL,
        string $localization = NULL,
        int $idCategory = NULL
    )
    {
        $this->id = $id;
        $this->title = $title;
        $this->abstract = $abstract;
        $this->localization = $localization;
        $this->idCategory = $idCategory;
    }

    public function insert() : bool
    {
        $query = "INSERT INTO ongs (title, abstract, localization, idCategory) VALUES (:title, :abstract, :localization, 2)";
        $stmt = Connect::getInstance()->prepare($query);
        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":abstract", $this->abstract);
        $stmt->bindParam(":localization", $this->localization);
        $stmt->execute();
    }

    public function findByCategory(int $idCategory)
    {
        $query = "SELECT * FROM ongs WHERE idCategory = :idCategory";
        $stmt = Connect::getInstance()->prepare($query);
        $stmt->bindParam(":idCategory",$idCategory);
        $stmt->execute();
        if($stmt->rowCount() == 0){
            return false;
        } else {
            return $stmt->fetchAll();
        }
    }

    public function selectAll()
    {
        $query = "SELECT * FROM ongs";
        $stmt = Connect::getInstance()->prepare($query);
        $stmt->execute();

        if($stmt->rowCount() == 0){
            return false;
        } else {
            return $stmt->fetchAll();
        }
    }

}