## Pasta Support
> Pasta para armazenar classes criadas a partir de módulos esxternos, por exemplo a DomPDF.