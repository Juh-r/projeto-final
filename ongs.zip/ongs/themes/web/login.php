<?php $this->layout("_theme", ["categories" => $categories]); ?>

    <img src="<?= url("assets/web/images/");?>dog.png" class="dog">
        
    <section class="page-section" id="contact">
            <div class="container">
                <img src="<?= url("assets/web/images/");?>dog.png" class="dog">
                <!-- Contact Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Entre</h2>
                <!-- Icon Divider-->
                <div class="divider-custom">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Contact Section Form-->
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-xl-7">
                        <!-- * * * * * * * * * * * * * * *-->
                        <!-- * * SB Forms Contact Form * *-->
                        <!-- * * * * * * * * * * * * * * *-->
                        <!-- This form is pre-integrated with SB Forms.-->
                        <!-- To make this form functional, sign up at-->
                        <!-- https://startbootstrap.com/solution/contact-forms-->
                        <!-- to get an API token!-->
                        <form id="loginForm" data-sb-form-api-token="API_TOKEN">
                            <!-- Email address input-->
                            <div class="form-floating mb-3">
                                <input name="email" value="" class="form-control" id="email" type="email" placeholder="name@example.com" data-sb-validations="required,email" />
                                <label for="email">Email</label>
                                <div class="invalid-feedback" data-sb-feedback="email:required">An email is required.</div>
                                <div class="invalid-feedback" data-sb-feedback="email:email">Email is not valid.</div>
                            </div>
                            <!-- Password input-->
                            <div class="form-floating mb-3">
                                <input name="password" value="" class="form-control" id="password" type="password" placeholder="Enter your message here..." data-sb-validations="required"/>
                                <label for="password">Senha</label>
                                <div class="invalid-feedback" data-sb-feedback="password:required">A message is required.</div>
                            </div>
                            <!-- Submit Button-->
                            <button class="btn btn-primary btn-xl" type="submit">Entrar</button>
                            <div class="row justify-content-center">
                                <div class="col-xl-4 col-lg-5 col-md-6 col-sm-7" id="message">
                                    <!-- Aqui aparece a mensagem, caso ocorra erro! -->
                                </div>
                                <!--<div class="text-center buttons bg-light">
                                    <a href="<?/*= url("restanteCad"); */?>" class="link mt-15 action-1 f-18 medium">Deseja completar o cadastro agora?</a>
                                </div>-->
                            </div>
                        </form>
                    </div>
                </div>
                <script type="text/javascript" async>
                    const form = document.querySelector("#loginForm");
                    const message = document.querySelector("#message");
                    form.addEventListener("submit", async (e) => {
                        e.preventDefault();
                        const dataUser = new FormData(form);
                        const data = await fetch("<?= url("login"); ?>",{
                            method: "POST",
                            body: dataUser,
                        });
                        const user = await data.json();
                        console.log(user);
                        if(user) {
                            if(user.type === "success"){
                                window.location.href = "app";
                            } else {
                                message.innerHTML = user.message;
                            }
                            message.classList.add("message");
                            message.classList.remove("success", "warning", "error");
                            message.classList.add(`${user.type}`);
                        }
                    });
                </script>
            </div>
        </section>