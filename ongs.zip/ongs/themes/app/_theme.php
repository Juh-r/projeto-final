<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title><?= CONF_SITE_NAME; ?></title>
    <link rel="stylesheet" type="text/css" href="estilo.css">

    <link href="<?= url("assets/app/"); ?>css/estilo.css" rel="stylesheet" />
  </head>
  <body>


  <nav class="navbar" id="nav">
    <div class="container logo">

    <!--<div class="logo-imagem>"><img src="cat.png" height="75px" width="75px"></div>-->
    
        <img class="logo-imagem" src="<?= url("assets/app/"); ?>cat.png" alt="..." />
    </div>


    <div class="menu">
            <ul>
                <li><a class="menu-link-1"  href="<?= url(""); ?>">Home</a></li>
                <li><a class="menu-link-2" href="<?= url("about"); ?>">Sobre</a></li>
                <li><a class="menu-link-3" href="<?= url("contact"); ?>">Contato</a></li>
                <li><a class="menu-link-3" >Faq</a></li>
                
            </ul>
        </div>

    
       <img class="profile-imagem" src="<?= url("assets/app/"); ?>account.png" alt="..." />
    
</nav>

<main>
        <?= $this->section("content"); ?>
    </main>

</body>
</html>