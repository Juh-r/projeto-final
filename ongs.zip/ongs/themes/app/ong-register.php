<?php
    $this->layout("_theme");
    //var_dump($categories);
?>
<div class="container">
<form enctype="multipart/form-data" method="post" id="formProjectRegister">
    <div class="mb-3">
        <label for="title" class="form-label">Nome da ONG: </label>
        <input type="text" name="title" class="form-control" id="title" value="nome da minha ong" placeholder="Nome da sua ong.....">
    </div>
    <div class="mb-3">
        <label for="abstract" class="form-label">Dê algumas informações sobre a sua ong: </label>
        <textarea name="abstract" class="form-control" id="exampleFormControlTextarea1" rows="3">Informações sobre sua ong.....</textarea>
    </div>



    <div class="mb-3">
        <label for="formFileMultiple" class="form-label">Imagens da ong:</label>
        <input name="images[]" class="form-control" type="file" id="formFileMultiple" multiple>
    </div>
  
    <div class="mb-3">
    <button type="submit" class="btn btn-primary" name="send">Registrar</button>
    </div>
    <div class="alert alert-primary" role="alert" id="message">
        Mensagem de Retorno!
    </div>
</form>
</div>
<script type="text/javascript" async>
    const form = document.querySelector("#formOngRegister");
    const message = document.querySelector("#message");
    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const dataOng = new FormData(form);
        const data = await fetch("<?= url("app/ong-register"); ?>",{
            method: "POST",
            body: dataOng,
        });
        const project = await data.json();
        console.log(ong);
        
    });
</script>